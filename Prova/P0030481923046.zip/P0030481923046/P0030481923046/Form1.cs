﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace P0030481923046
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            string valor = "";
            int linha, coluna;
            double[,] vetor = new double[6, 4];
            double[] TotalporMes = new double[6] { 0, 0, 0, 0, 0, 0};
            int x = 0;
            double TotalGeral = 0;
            for(linha=0; linha<6; linha++)
            {               
                for(coluna=0; coluna<4; coluna++)
                {

                    valor = Interaction.InputBox("Digite o valor vendido no mês " + (linha + 1) + " semana " + (coluna + 1), "Entrada de dados");
                    if(double.TryParse(valor, out vetor[linha,coluna]))
                    {
                        TotalporMes[x] = TotalporMes[x] + vetor[linha,coluna];
                    }
                    else
                    {
                        MessageBox.Show("Digite um valor válido!");
                        coluna--;
                    }
                }

                TotalGeral = TotalGeral + TotalporMes[x];
                x++;


            }

            for(x=0;x<6;x++)
            {
                for(coluna=0;coluna<4;coluna++)
                {
                    lstbxVendas.Items.Add("Total do mês " + (x + 1) + " - Semana " + (coluna + 1) + " R$" + vetor[x, coluna].ToString("N2"));
                }
                lstbxVendas.Items.Add(">> Total do mês " + (x+1) + ": R$ " + TotalporMes[x].ToString("N2"));
            }
            lstbxVendas.Items.Add(">> Total Geral: R$ " + TotalGeral.ToString("N2"));
        }
    }
}

